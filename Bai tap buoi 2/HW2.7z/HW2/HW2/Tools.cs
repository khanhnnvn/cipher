﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Numerics;
using System.Threading;
using System.Windows.Forms;

namespace HW2
{
    class Tools 
    {
        //convert string to bigint
        private static BigInteger Str2Bigint(string s)
        {
            BigInteger result;
            result = BigInteger.Parse(s);
            return result;
        }

        //Function for Power bigint
        public static string PowStr(string str1, string str2)
        {
            string result;
            BigInteger ba1 = Str2Bigint(str1);
            int ib1 = int.Parse(str2);
            result = BigInteger.Pow(ba1, ib1).ToString();
            return result;
        }
        //Funtion Modulo
        public static string Modulo(string str1, string str2, string str3, string str4)
        {
            BigInteger number = Str2Bigint(str1);
            int exponent = int.Parse(str2);
            BigInteger modulo = Str2Bigint(str3);
            int exmodulo = int.Parse(str4);
            BigInteger modulus = BigInteger.Pow(modulo, exmodulo);
            string result = "";
            result = string.Format("{0}^{1} mod {2}^{3} = {4}", str1, str2, str3, str4, BigInteger.ModPow(number, exponent, modulus));
            return result;
        }

        //200*200

        private string numberAsString;
        private const int MAXLENGTH = 10000;


        public Tools(string numberAsString)
        {
            this.numberAsString = numberAsString;
        }


        public Tools(ulong longNumber)
        {
            this.numberAsString = Convert.ToString(longNumber);
        }

        //Function addition 
        public static Tools Add(Tools Tools1, Tools Tools2)
        {
            char[] outputChars = new char[MAXLENGTH];
            string veryLongString1 = Reverse(Tools1.ToString());
            string veryLongString2 = Reverse(Tools2.ToString());
            int length1 = veryLongString1.Length;
            int length2 = veryLongString2.Length;
            int maxLength = length1 > length2 ? length1 : length2;
            int carry = 0;
            int j = 0;
            for (j = 0; j < maxLength; j++)
            {
                int digit1 = (j > length1 - 1) ? 0 : Convert.ToInt32(veryLongString1[j].ToString());
                int digit2 = (j > length2 - 1) ? 0 : Convert.ToInt32(veryLongString2[j].ToString());
                int digitsum = digit1 + digit2 + carry;
                if (digitsum >= 10)
                {
                    digitsum -= 10;
                    carry = 1;
                }
                else
                    carry = 0;
                outputChars[j] = Convert.ToChar(Convert.ToString(digitsum));
            }
            if (carry == 1)
                outputChars[j++] = '1';
            return new Tools(Reverse(new string(outputChars)));
        }

        //Function multiplication
        public static Tools Multi(Tools Tools1, Tools Tools2)
        {
            char[] outputChars = new char[MAXLENGTH];
            string veryLongString = Reverse(Tools2.ToString());
            Tools powerproduct = null;
            Tools outputTools = new Tools("0");
            int j = 0;
            for (j = 0; j < veryLongString.Length; j++)
            {
                int digit = Convert.ToInt32(veryLongString[j].ToString());
                powerproduct = MultiplyDigit(Tools1, digit);
                for (int k = 0; k < j; k++)
                {
                    powerproduct = Multiply10(powerproduct);
                }
                outputTools = Add(outputTools, powerproduct);
            }
            return outputTools;
        }
        //function power string - string
        public static Tools pw(Tools Tools1, int pwr)
        {
            Tools outputTools = Tools1;
            int j = 0;
            for (j = 1; j < pwr; j++)
            {
                outputTools = Multi(Tools1, outputTools);
            }
            return outputTools;
        }

        // reverses the given string.
        public static string Reverse(string numberString)
        {
            int j = 0;
            char[] outputChars = new char[numberString.Length];
            for (int i = numberString.Length - 1; i >= 0; i--)
            {
                outputChars[j] = numberString[i];
                j++;
            }
            return new string(outputChars);
        }

        //Function multiplication string with int
        private static Tools MultiplyDigit(Tools Tools, int digit)
        {
            char[] outputChars = new char[MAXLENGTH];
            int carry = 0;
            string veryLongString = Reverse(Tools.ToString());
            int j = 0;
            for (j = 0; j < veryLongString.Length; j++)
            {
                int digit1 = Convert.ToInt32(veryLongString[j].ToString());
                int digitproduct = digit1 * digit;
                digitproduct += carry;
                if (digitproduct >= 10)
                {
                    carry = digitproduct / 10;
                    digitproduct -= carry * 10;
                }
                else
                    carry = 0;
                outputChars[j] = Convert.ToChar(Convert.ToString(digitproduct));
            }
            if (carry != 0)
                outputChars[j++] = Convert.ToChar(Convert.ToString(carry));
            return new Tools(Reverse(new string(outputChars)));
        }

        //function multiplication 10
        private static Tools Multiply10(Tools vl)
        {
            char[] outputChars = new char[MAXLENGTH];
            string veryLongString = Reverse(vl.ToString());
            for (int j = veryLongString.Length - 1; j >= 0; j--)
            {
                outputChars[j + 1] = veryLongString[j];
            }
            outputChars[0] = '0';
            return new Tools(Reverse(new string(outputChars)));
        }
        //200*200

    }
}
