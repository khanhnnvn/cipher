﻿namespace HW2
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.textBox1R = new System.Windows.Forms.TextBox();
            this.textBox1R1cP1d = new System.Windows.Forms.TextBox();
            this.textBox1R1aP1b = new System.Windows.Forms.TextBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.button1Clear = new System.Windows.Forms.Button();
            this.textBox1TimePMulti = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.textBox1TimeP2 = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.button1PowMulti = new System.Windows.Forms.Button();
            this.textBox1TimeM = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.textBox1TimeP1 = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.button1Result = new System.Windows.Forms.Button();
            this.button1Pow2 = new System.Windows.Forms.Button();
            this.button1Pow1 = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.textBox1D = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.textBox1C = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.textBox1B = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.textBox1A = new System.Windows.Forms.TextBox();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.textBox2Result = new System.Windows.Forms.TextBox();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.button2Calculator = new System.Windows.Forms.Button();
            this.textBox2Time = new System.Windows.Forms.TextBox();
            this.textBox2LeResult = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.textBox2LeNum2 = new System.Windows.Forms.TextBox();
            this.textBox2LeNum1 = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.textBox2Num2 = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.textBox2Num1 = new System.Windows.Forms.TextBox();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.Location = new System.Drawing.Point(0, 0);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1382, 723);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.groupBox2);
            this.tabPage1.Controls.Add(this.groupBox3);
            this.tabPage1.Controls.Add(this.groupBox1);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(1374, 697);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Modulo & Multithreading";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.textBox1R);
            this.groupBox2.Controls.Add(this.textBox1R1cP1d);
            this.groupBox2.Controls.Add(this.textBox1R1aP1b);
            this.groupBox2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox2.Location = new System.Drawing.Point(3, 153);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(1368, 441);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Result";
            // 
            // textBox1R
            // 
            this.textBox1R.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBox1R.Location = new System.Drawing.Point(3, 376);
            this.textBox1R.Multiline = true;
            this.textBox1R.Name = "textBox1R";
            this.textBox1R.ReadOnly = true;
            this.textBox1R.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.textBox1R.Size = new System.Drawing.Size(1362, 62);
            this.textBox1R.TabIndex = 2;
            // 
            // textBox1R1cP1d
            // 
            this.textBox1R1cP1d.Dock = System.Windows.Forms.DockStyle.Top;
            this.textBox1R1cP1d.Location = new System.Drawing.Point(3, 196);
            this.textBox1R1cP1d.Multiline = true;
            this.textBox1R1cP1d.Name = "textBox1R1cP1d";
            this.textBox1R1cP1d.ReadOnly = true;
            this.textBox1R1cP1d.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.textBox1R1cP1d.Size = new System.Drawing.Size(1362, 180);
            this.textBox1R1cP1d.TabIndex = 1;
            // 
            // textBox1R1aP1b
            // 
            this.textBox1R1aP1b.Dock = System.Windows.Forms.DockStyle.Top;
            this.textBox1R1aP1b.Location = new System.Drawing.Point(3, 16);
            this.textBox1R1aP1b.Multiline = true;
            this.textBox1R1aP1b.Name = "textBox1R1aP1b";
            this.textBox1R1aP1b.ReadOnly = true;
            this.textBox1R1aP1b.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.textBox1R1aP1b.Size = new System.Drawing.Size(1362, 180);
            this.textBox1R1aP1b.TabIndex = 0;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.button1Clear);
            this.groupBox3.Controls.Add(this.textBox1TimePMulti);
            this.groupBox3.Controls.Add(this.label7);
            this.groupBox3.Controls.Add(this.textBox1TimeP2);
            this.groupBox3.Controls.Add(this.label6);
            this.groupBox3.Controls.Add(this.button1PowMulti);
            this.groupBox3.Controls.Add(this.textBox1TimeM);
            this.groupBox3.Controls.Add(this.label5);
            this.groupBox3.Controls.Add(this.textBox1TimeP1);
            this.groupBox3.Controls.Add(this.label4);
            this.groupBox3.Controls.Add(this.button1Result);
            this.groupBox3.Controls.Add(this.button1Pow2);
            this.groupBox3.Controls.Add(this.button1Pow1);
            this.groupBox3.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.groupBox3.Location = new System.Drawing.Point(3, 594);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(1368, 100);
            this.groupBox3.TabIndex = 2;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Function";
            // 
            // button1Clear
            // 
            this.button1Clear.Location = new System.Drawing.Point(574, 29);
            this.button1Clear.Name = "button1Clear";
            this.button1Clear.Size = new System.Drawing.Size(100, 50);
            this.button1Clear.TabIndex = 12;
            this.button1Clear.Text = "Clear";
            this.button1Clear.UseVisualStyleBackColor = true;
            this.button1Clear.Click += new System.EventHandler(this.button1Clear_Click);
            // 
            // textBox1TimePMulti
            // 
            this.textBox1TimePMulti.Location = new System.Drawing.Point(341, 66);
            this.textBox1TimePMulti.Name = "textBox1TimePMulti";
            this.textBox1TimePMulti.ReadOnly = true;
            this.textBox1TimePMulti.Size = new System.Drawing.Size(100, 20);
            this.textBox1TimePMulti.TabIndex = 11;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(237, 70);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(98, 13);
            this.label7.TabIndex = 10;
            this.label7.Text = "Time PowMulti (ms)";
            // 
            // textBox1TimeP2
            // 
            this.textBox1TimeP2.Location = new System.Drawing.Point(341, 28);
            this.textBox1TimeP2.Name = "textBox1TimeP2";
            this.textBox1TimeP2.ReadOnly = true;
            this.textBox1TimeP2.Size = new System.Drawing.Size(100, 20);
            this.textBox1TimeP2.TabIndex = 9;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(234, 32);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(82, 13);
            this.label6.TabIndex = 8;
            this.label6.Text = "Time Pow2 (ms)";
            // 
            // button1PowMulti
            // 
            this.button1PowMulti.Location = new System.Drawing.Point(824, 29);
            this.button1PowMulti.Name = "button1PowMulti";
            this.button1PowMulti.Size = new System.Drawing.Size(100, 50);
            this.button1PowMulti.TabIndex = 7;
            this.button1PowMulti.Text = "PowNumberMulti";
            this.button1PowMulti.UseVisualStyleBackColor = true;
            this.button1PowMulti.Click += new System.EventHandler(this.button1PowMulti_Click);
            // 
            // textBox1TimeM
            // 
            this.textBox1TimeM.Location = new System.Drawing.Point(103, 66);
            this.textBox1TimeM.Name = "textBox1TimeM";
            this.textBox1TimeM.ReadOnly = true;
            this.textBox1TimeM.Size = new System.Drawing.Size(100, 20);
            this.textBox1TimeM.TabIndex = 6;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(7, 70);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(90, 13);
            this.label5.TabIndex = 5;
            this.label5.Text = "Time Modulo (ms)";
            // 
            // textBox1TimeP1
            // 
            this.textBox1TimeP1.Location = new System.Drawing.Point(103, 28);
            this.textBox1TimeP1.Name = "textBox1TimeP1";
            this.textBox1TimeP1.ReadOnly = true;
            this.textBox1TimeP1.Size = new System.Drawing.Size(100, 20);
            this.textBox1TimeP1.TabIndex = 4;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(7, 32);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(82, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "Time Pow1 (ms)";
            // 
            // button1Result
            // 
            this.button1Result.Location = new System.Drawing.Point(1148, 29);
            this.button1Result.Name = "button1Result";
            this.button1Result.Size = new System.Drawing.Size(100, 50);
            this.button1Result.TabIndex = 2;
            this.button1Result.Text = "Modulo";
            this.button1Result.UseVisualStyleBackColor = true;
            this.button1Result.Click += new System.EventHandler(this.button1Result_Click);
            // 
            // button1Pow2
            // 
            this.button1Pow2.Location = new System.Drawing.Point(1040, 29);
            this.button1Pow2.Name = "button1Pow2";
            this.button1Pow2.Size = new System.Drawing.Size(100, 50);
            this.button1Pow2.TabIndex = 1;
            this.button1Pow2.Text = "PowModulo/PowNumber1";
            this.button1Pow2.UseVisualStyleBackColor = true;
            this.button1Pow2.Click += new System.EventHandler(this.button1Pow2_Click);
            // 
            // button1Pow1
            // 
            this.button1Pow1.Location = new System.Drawing.Point(932, 29);
            this.button1Pow1.Name = "button1Pow1";
            this.button1Pow1.Size = new System.Drawing.Size(100, 50);
            this.button1Pow1.TabIndex = 0;
            this.button1Pow1.Text = "PowNumber1";
            this.button1Pow1.UseVisualStyleBackColor = true;
            this.button1Pow1.Click += new System.EventHandler(this.button1Pow1_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.textBox1D);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.textBox1C);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.textBox1B);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.textBox1A);
            this.groupBox1.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupBox1.Location = new System.Drawing.Point(3, 3);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(1368, 150);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Input";
            // 
            // textBox1D
            // 
            this.textBox1D.Dock = System.Windows.Forms.DockStyle.Left;
            this.textBox1D.Location = new System.Drawing.Point(1067, 16);
            this.textBox1D.Multiline = true;
            this.textBox1D.Name = "textBox1D";
            this.textBox1D.Size = new System.Drawing.Size(300, 131);
            this.textBox1D.TabIndex = 6;
            this.textBox1D.Text = "1";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Dock = System.Windows.Forms.DockStyle.Left;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 30F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(1034, 16);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(33, 46);
            this.label3.TabIndex = 5;
            this.label3.Text = "^";
            // 
            // textBox1C
            // 
            this.textBox1C.Dock = System.Windows.Forms.DockStyle.Left;
            this.textBox1C.Location = new System.Drawing.Point(734, 16);
            this.textBox1C.Multiline = true;
            this.textBox1C.Name = "textBox1C";
            this.textBox1C.Size = new System.Drawing.Size(300, 131);
            this.textBox1C.TabIndex = 4;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Dock = System.Windows.Forms.DockStyle.Left;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 30F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(636, 16);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(98, 46);
            this.label2.TabIndex = 3;
            this.label2.Text = "mod";
            // 
            // textBox1B
            // 
            this.textBox1B.Dock = System.Windows.Forms.DockStyle.Left;
            this.textBox1B.Location = new System.Drawing.Point(336, 16);
            this.textBox1B.Multiline = true;
            this.textBox1B.Name = "textBox1B";
            this.textBox1B.Size = new System.Drawing.Size(300, 131);
            this.textBox1B.TabIndex = 2;
            this.textBox1B.Text = "1";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Dock = System.Windows.Forms.DockStyle.Left;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 30F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(303, 16);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(33, 46);
            this.label1.TabIndex = 1;
            this.label1.Text = "^";
            // 
            // textBox1A
            // 
            this.textBox1A.Dock = System.Windows.Forms.DockStyle.Left;
            this.textBox1A.Location = new System.Drawing.Point(3, 16);
            this.textBox1A.Multiline = true;
            this.textBox1A.Name = "textBox1A";
            this.textBox1A.Size = new System.Drawing.Size(300, 131);
            this.textBox1A.TabIndex = 0;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.groupBox6);
            this.tabPage2.Controls.Add(this.groupBox5);
            this.tabPage2.Controls.Add(this.groupBox4);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(1374, 697);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Multi Array";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.textBox2Result);
            this.groupBox6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox6.Location = new System.Drawing.Point(3, 217);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(1368, 377);
            this.groupBox6.TabIndex = 2;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Result";
            // 
            // textBox2Result
            // 
            this.textBox2Result.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBox2Result.Location = new System.Drawing.Point(3, 16);
            this.textBox2Result.Multiline = true;
            this.textBox2Result.Name = "textBox2Result";
            this.textBox2Result.ReadOnly = true;
            this.textBox2Result.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.textBox2Result.Size = new System.Drawing.Size(1362, 358);
            this.textBox2Result.TabIndex = 0;
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.button2Calculator);
            this.groupBox5.Controls.Add(this.textBox2Time);
            this.groupBox5.Controls.Add(this.textBox2LeResult);
            this.groupBox5.Controls.Add(this.label12);
            this.groupBox5.Controls.Add(this.label11);
            this.groupBox5.Controls.Add(this.textBox2LeNum2);
            this.groupBox5.Controls.Add(this.textBox2LeNum1);
            this.groupBox5.Controls.Add(this.label10);
            this.groupBox5.Controls.Add(this.label9);
            this.groupBox5.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.groupBox5.Location = new System.Drawing.Point(3, 594);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(1368, 100);
            this.groupBox5.TabIndex = 1;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Function";
            // 
            // button2Calculator
            // 
            this.button2Calculator.Location = new System.Drawing.Point(591, 29);
            this.button2Calculator.Name = "button2Calculator";
            this.button2Calculator.Size = new System.Drawing.Size(100, 50);
            this.button2Calculator.TabIndex = 8;
            this.button2Calculator.Text = "Calculator";
            this.button2Calculator.UseVisualStyleBackColor = true;
            this.button2Calculator.Click += new System.EventHandler(this.button2Calculator_Click);
            // 
            // textBox2Time
            // 
            this.textBox2Time.Location = new System.Drawing.Point(379, 62);
            this.textBox2Time.Name = "textBox2Time";
            this.textBox2Time.ReadOnly = true;
            this.textBox2Time.Size = new System.Drawing.Size(150, 20);
            this.textBox2Time.TabIndex = 7;
            // 
            // textBox2LeResult
            // 
            this.textBox2LeResult.Location = new System.Drawing.Point(379, 25);
            this.textBox2LeResult.Name = "textBox2LeResult";
            this.textBox2LeResult.ReadOnly = true;
            this.textBox2LeResult.Size = new System.Drawing.Size(150, 20);
            this.textBox2LeResult.TabIndex = 6;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(290, 69);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(80, 13);
            this.label12.TabIndex = 5;
            this.label12.Text = "Time Calculator";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(290, 32);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(73, 13);
            this.label11.TabIndex = 4;
            this.label11.Text = "Length Result";
            // 
            // textBox2LeNum2
            // 
            this.textBox2LeNum2.Location = new System.Drawing.Point(103, 62);
            this.textBox2LeNum2.Name = "textBox2LeNum2";
            this.textBox2LeNum2.ReadOnly = true;
            this.textBox2LeNum2.Size = new System.Drawing.Size(150, 20);
            this.textBox2LeNum2.TabIndex = 3;
            // 
            // textBox2LeNum1
            // 
            this.textBox2LeNum1.Location = new System.Drawing.Point(103, 25);
            this.textBox2LeNum1.Name = "textBox2LeNum1";
            this.textBox2LeNum1.ReadOnly = true;
            this.textBox2LeNum1.Size = new System.Drawing.Size(150, 20);
            this.textBox2LeNum1.TabIndex = 2;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(7, 69);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(89, 13);
            this.label10.TabIndex = 1;
            this.label10.Text = "Length Number 2";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(7, 32);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(89, 13);
            this.label9.TabIndex = 0;
            this.label9.Text = "Length Number 1";
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.textBox2Num2);
            this.groupBox4.Controls.Add(this.label8);
            this.groupBox4.Controls.Add(this.textBox2Num1);
            this.groupBox4.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupBox4.Location = new System.Drawing.Point(3, 3);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(1368, 214);
            this.groupBox4.TabIndex = 0;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Input";
            // 
            // textBox2Num2
            // 
            this.textBox2Num2.Dock = System.Windows.Forms.DockStyle.Left;
            this.textBox2Num2.Location = new System.Drawing.Point(702, 16);
            this.textBox2Num2.Multiline = true;
            this.textBox2Num2.Name = "textBox2Num2";
            this.textBox2Num2.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.textBox2Num2.Size = new System.Drawing.Size(664, 195);
            this.textBox2Num2.TabIndex = 2;
            this.textBox2Num2.TextChanged += new System.EventHandler(this.textBox2Num2_TextChanged);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Dock = System.Windows.Forms.DockStyle.Left;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 30F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(667, 16);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(35, 46);
            this.label8.TabIndex = 1;
            this.label8.Text = "*";
            // 
            // textBox2Num1
            // 
            this.textBox2Num1.Dock = System.Windows.Forms.DockStyle.Left;
            this.textBox2Num1.Location = new System.Drawing.Point(3, 16);
            this.textBox2Num1.Multiline = true;
            this.textBox2Num1.Name = "textBox2Num1";
            this.textBox2Num1.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.textBox2Num1.Size = new System.Drawing.Size(664, 195);
            this.textBox2Num1.TabIndex = 0;
            this.textBox2Num1.TextChanged += new System.EventHandler(this.textBox2Num1_TextChanged);
            // 
            // tabPage3
            // 
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Size = new System.Drawing.Size(1374, 697);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "LZW";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1382, 723);
            this.Controls.Add(this.tabControl1);
            this.Name = "Form1";
            this.Text = "HW2";
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TextBox textBox1D;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBox1C;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBox1B;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBox1A;
        private System.Windows.Forms.TextBox textBox1R;
        private System.Windows.Forms.TextBox textBox1R1cP1d;
        private System.Windows.Forms.TextBox textBox1R1aP1b;
        private System.Windows.Forms.Button button1Result;
        private System.Windows.Forms.Button button1Pow2;
        private System.Windows.Forms.Button button1Pow1;
        private System.Windows.Forms.TextBox textBox1TimeM;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox textBox1TimeP1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button button1PowMulti;
        private System.Windows.Forms.TextBox textBox1TimePMulti;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox textBox1TimeP2;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button button1Clear;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.TextBox textBox2Result;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.TextBox textBox2Time;
        private System.Windows.Forms.TextBox textBox2LeResult;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox textBox2LeNum2;
        private System.Windows.Forms.TextBox textBox2LeNum1;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.TextBox textBox2Num2;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox textBox2Num1;
        private System.Windows.Forms.Button button2Calculator;
        private System.Windows.Forms.TabPage tabPage3;
    }
}

