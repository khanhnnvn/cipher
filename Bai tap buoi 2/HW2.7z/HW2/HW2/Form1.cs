﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Diagnostics;
using System.Threading;
using System.Numerics;

namespace HW2
{
    public partial class Form1 : Form
    {
        //Validation textbox only number
        public Form1()
        {
            InitializeComponent();
            textBox1A.KeyPress += new KeyPressEventHandler(ValiPress);
            textBox1B.KeyPress += new KeyPressEventHandler(ValiPress);
            textBox1C.KeyPress += new KeyPressEventHandler(ValiPress);
            textBox1D.KeyPress += new KeyPressEventHandler(ValiPress);
            textBox2Num1.KeyPress += new KeyPressEventHandler(ValiPress);
            textBox2Num2.KeyPress += new KeyPressEventHandler(ValiPress);
            //CheckForIllegalCrossThreadCalls = false;
        }

        private void ValiPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar >= '0' && e.KeyChar <= '9' || (char.IsControl(e.KeyChar)))
            {
                e.Handled = false;
            }
            else
            {
                e.Handled = true;
            }
        }

        private void button1Pow1_Click(object sender, EventArgs e)
        {
            Stopwatch watch = new Stopwatch();
            string s1a = textBox1A.Text;
            string s1b = textBox1B.Text;
            watch.Start();
            textBox1R1aP1b.Text = Tools.PowStr(s1a, s1b);
            watch.Stop();
            TimeSpan ts = watch.Elapsed;
            textBox1TimeP1.Text = ts.ToString();
        }

        private void button1Pow2_Click(object sender, EventArgs e)
        {
            Stopwatch watch = new Stopwatch();
            string s1a = textBox1C.Text;
            string s1b = textBox1D.Text;
            watch.Start();
            textBox1R1cP1d.Text = Tools.PowStr(s1a, s1b);
            watch.Stop();
            TimeSpan ts = watch.Elapsed;
            textBox1TimeP2.Text = ts.ToString();
        }

        private void button1Result_Click(object sender, EventArgs e)
        {
            string s1a = textBox1A.Text;
            string s1b = textBox1B.Text;
            string s1c = textBox1C.Text;
            string s1d = textBox1D.Text;
            Stopwatch watch = new Stopwatch();
            watch.Start();
            textBox1R.Text = Tools.Modulo(s1a, s1b, s1c, s1d);
            watch.Stop();
            TimeSpan ts = watch.Elapsed;
            textBox1TimeM.Text = ts.ToString();
        }

        private void button1PowMulti_Click(object sender, EventArgs e)
        {
            string s1a = textBox1A.Text;
            string s1b = textBox1B.Text;
            string s1c = textBox1C.Text;
            string s1d = textBox1D.Text;
            Stopwatch watch = new Stopwatch();
            watch.Start();
            textBox1R1aP1b.Text = Tools.PowStr(s1a, s1b);
            Thread FirstThread = new Thread(() => Thread1(s1a, s1b));
            Thread SecondThread = new Thread(() => Thread2(s1c, s1d));
            FirstThread.Start();
            SecondThread.Start();

            watch.Stop();
            TimeSpan ts = watch.Elapsed;
            textBox1TimePMulti.Text = ts.ToString();
        }

        //Thread 1
        private void Thread1(string str1, string str2)
        {
            if (this.InvokeRequired)
            {
                if (this.InvokeRequired)
                {
                    this.Invoke(
                        new MethodInvoker(
                            delegate() { Thread1(str1, str2); }));
                }
                else
                {
                    textBox1R1aP1b.Text = Tools.PowStr(str1, str2);
                }
            }
        }

        //Thread 2
        private void Thread2(string str1, string str2)
        {
            if (this.InvokeRequired)
            {
                this.Invoke(
                    new MethodInvoker(
                        delegate() {Thread2(str1, str2); }));
            }
            else
            {
                textBox1R1cP1d.Text = Tools.PowStr(str1, str2);
            }
        }
        //Clear result textbox
        private void button1Clear_Click(object sender, EventArgs e)
        {
            textBox1R1aP1b.Clear();
            textBox1R1cP1d.Clear();
            textBox1R.Clear();
        }
        //multiplication string with string
        private void button2Calculator_Click(object sender, EventArgs e)
        {
            Tools v1 = new Tools(textBox2Num1.Text);
            Tools v2 = new Tools(textBox2Num2.Text);
            Stopwatch watch = new Stopwatch();
            watch.Start();
            textBox2Result.Text = (Tools.Multi(v1,v2)).ToString();
            watch.Stop();
            TimeSpan ts = watch.Elapsed;
            textBox2Time.Text = ts.ToString();
            textBox2LeResult.Text = textBox2Result.Text.Length.ToString();
        }

        private void textBox2Num1_TextChanged(object sender, EventArgs e)
        {
            textBox2LeNum1.Text = textBox2Num1.Text.Length.ToString();
        }

        private void textBox2Num2_TextChanged(object sender, EventArgs e)
        {
            textBox2LeNum2.Text = textBox2Num2.Text.Length.ToString();
        }
    }
}
